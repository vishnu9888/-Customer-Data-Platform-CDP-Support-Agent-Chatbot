# A skill provides a teams task module

> The Skill responds to an action/submit invoke with a `taskInfo` object containing a Task Module with an Adaptive Card
> The Skill responds to the submit action of a TaskModule

## Variations

- TODO

## Testing matrix

- Skill: [Teams skill](../SkillsFunctionalTesting.md#teams-skill)
- Topology: [Simple](../SkillsFunctionalTesting.md#simple)

![Test matrix](../media/Simple.jpg)

## Variables

- Auth context: Public Cloud, Gov Cloud, Sandboxed
- Delivery mode: Normal, ExpectReplies

## Total test cases

96 (not including variations)
