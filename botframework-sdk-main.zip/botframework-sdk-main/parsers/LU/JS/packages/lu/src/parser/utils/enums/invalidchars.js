/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
 // Invalid chars in intent or entity name
module.exports = {
    InvalidCharsInIntentOrEntityName: ['<', '>', '*', '%', '&', ':', '\\', '$']
};