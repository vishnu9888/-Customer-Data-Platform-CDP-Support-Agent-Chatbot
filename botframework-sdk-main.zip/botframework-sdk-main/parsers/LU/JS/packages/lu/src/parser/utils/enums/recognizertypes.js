/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
module.exports = {
    LUIS: 'luis',
    QNAMAKER: 'qnamaker',
    MULTILANGUAGE: 'multiLanguage',
    CROSSTRAINED: 'crosstrained'
};