const QnaSectionContext = require('./generated/LUFileParser').LUFileParser.QnaSectionContext;
const LUSectionTypes = require('./../utils/enums/lusectiontypes');
const BuildDiagnostic = require('./diagnostic').BuildDiagnostic;
const QNA_GENERIC_SOURCE = "custom editorial";
const BaseSection = require('./baseSection');
const Range = require('./diagnostic').Range;
const Position = require('./diagnostic').Position;

class QnaSection extends BaseSection {
    /**
     * 
     * @param {QnaSectionContext} parseTree 
     */
    constructor(parseTree) {
        super();
        this.SectionType = LUSectionTypes.QNASECTION;
        this.Questions = [this.ExtractQuestion(parseTree)];
        let result = this.ExtractMoreQuestions(parseTree);
        this.Questions = this.Questions.concat(result.questions);
        this.Errors = result.errors;
        result = this.ExtractFilterPairs(parseTree);
        this.FilterPairs = result.filterPairs;
        this.Errors = this.Errors.concat(result.errors);
        this.Answer = this.ExtractAnswer(parseTree);
        result = this.ExtractPrompts(parseTree);
        this.prompts = result.promptDefinitions;
        this.promptsText = result.promptTextList;
        this.Errors = this.Errors.concat(result.errors);
        this.QAPairId = this.ExtractAssignedId(parseTree);
        this.source = this.ExtractSourceInfo(parseTree);
        const startPosition = new Position(parseTree.start.line, parseTree.start.column);
        const stopPosition = new Position(parseTree.stop.line, parseTree.stop.column + parseTree.stop.text.length);
        this.Range = new Range(startPosition, stopPosition);
    }

    ExtractSourceInfo(parseTree) {
        let srcAssignment = parseTree.qnaDefinition().qnaSourceInfo()
        if (srcAssignment) {
            let srcRegExp = /^[ ]*\>[ ]*!#[ ]*@qna.pair.source[ ]*=[ ]*(?<sourceInfo>.*?)$/gmi;
            let srcParsed = srcRegExp.exec(srcAssignment.getText().trim());
            return srcParsed.groups.sourceInfo || QNA_GENERIC_SOURCE;
        }
        return QNA_GENERIC_SOURCE
    }
    
    ExtractAssignedId(parseTree) {
        let idAssignment = parseTree.qnaDefinition().qnaIdMark()
        if (idAssignment) {
            let idTextRegExp = /^\<a[ ]*id[ ]*=[ ]*[\"\'](?<idCaptured>.*?)[\"\'][ ]*>[ ]*\<\/a\>$/gmi;
            let idTextParsed = idTextRegExp.exec(idAssignment.getText().trim());
            return idTextParsed.groups.idCaptured || undefined;
        }
        return undefined;
    }

    ExtractPrompts(parseTree) {
        let promptDefinitions = [];
        let promptTextList = []
        let errors = [];
        let promptSection = parseTree.qnaDefinition().promptSection();
        if (!promptSection) {
            return { promptDefinitions, errors };
        }
        if (promptSection.errorFilterLine() !== undefined) {
            for (const errorFilterLineStr of promptSection.errorFilterLine()) {
                if (errorFilterLineStr.getText().trim() !== '') {
                    errors.push(BuildDiagnostic({
                    message: "Invalid QnA prompt line, expecting '-' prefix for each line.",
                    context: errorFilterLineStr
                }))}
            }
        }
        
        for (const promptLine of promptSection.filterLine()) {
            let filterLineText = promptLine.getText().trim();
            filterLineText = filterLineText.substr(1).trim();
            promptTextList.push(filterLineText);
            let promptConfigurationRegExp = /^\[(?<displayText>.*?)]\([ ]*\#[ ]*[ ?]*(?<linkedQuestion>.*?)\)[ ]*(?<contextOnly>\`context-only\`)?.*?$/gmi;
            let splitLine = promptConfigurationRegExp.exec(filterLineText);
            if (!splitLine) {
                errors.push(BuildDiagnostic({
                    message: "Invalid QnA prompt definition. Unable to parse prompt. Please verify syntax as well as question link`.",
                    context: filterLineText
                }))
            }
            promptDefinitions.push(splitLine.groups);
        }
        return { promptDefinitions, promptTextList, errors };
    }

    ExtractQuestion(parseTree) {
        return parseTree.qnaDefinition().qnaQuestion().questionText().getText().trim();
    }

    ExtractMoreQuestions(parseTree) {
        let questions = [];
        let errors = [];
        let questionsBody = parseTree.qnaDefinition().moreQuestionsBody();
        for (const errorQuestionStr of questionsBody.errorQuestionString()) {
            if (errorQuestionStr.getText().trim() !== '') {
                errors.push(BuildDiagnostic({
                message: "Invalid QnA question line, did you miss '-' at line begin",
                context: errorQuestionStr
            }))}
        }

        for (const question of questionsBody.moreQuestion()) {
            let questionText = question.getText().trim();
            questions.push(questionText.substr(1).trim());
        }

        return { questions, errors };
    }

    ExtractFilterPairs(parseTree) {
        let filterPairs = [];
        let errors = [];
        let filterSection = parseTree.qnaDefinition().qnaAnswerBody().filterSection();
        if (filterSection) {
            if (filterSection.errorFilterLine() !== undefined) {
                for (const errorFilterLineStr of filterSection.errorFilterLine()) {
                    if (errorFilterLineStr.getText().trim() !== '') {
                        errors.push(BuildDiagnostic({
                        message: "Invalid QnA filter line, did you miss '-' at line begin",
                        context: errorFilterLineStr
                    }))}
                }
            }
            
            for (const filterLine of filterSection.filterLine()) {
                let filterLineText = filterLine.getText().trim();
                filterLineText = filterLineText.substr(1).trim()
                let filterPair = filterLineText.split('=');
                let key = filterPair[0].trim();
                let value = filterPair[1].trim();
                filterPairs.push({ key, value });
            }
        } 

        return { filterPairs, errors };
    }

    ExtractAnswer(parseTree) {
        let multiLineAnswer = parseTree.qnaDefinition().qnaAnswerBody().multiLineAnswer().getText().trim();
        // trim first and last line
        let answerRegexp = /^```(markdown)?\r*\n(?<answer>(.|\n|\r\n|\t| )*)\r?\n.*?```$/gim;
        let answer = answerRegexp.exec(multiLineAnswer);
        return answer.groups.answer !== undefined ? answer.groups.answer : '';
    }
}

module.exports = QnaSection;