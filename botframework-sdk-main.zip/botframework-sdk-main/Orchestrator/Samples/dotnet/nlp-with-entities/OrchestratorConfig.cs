﻿namespace Microsoft.BotBuilderSamples
{
    public class OrchestratorConfig
    {
        public string SnapshotFile { get; set; }
        
        public string ModelFolder { get; set; }
    }
}
