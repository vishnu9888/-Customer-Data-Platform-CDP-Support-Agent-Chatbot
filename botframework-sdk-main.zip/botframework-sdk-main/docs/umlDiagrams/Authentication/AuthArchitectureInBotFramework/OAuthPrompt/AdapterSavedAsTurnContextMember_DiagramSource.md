```mermaid
    graph LR
        Adapter -- stored as member in --> TurnContext
```