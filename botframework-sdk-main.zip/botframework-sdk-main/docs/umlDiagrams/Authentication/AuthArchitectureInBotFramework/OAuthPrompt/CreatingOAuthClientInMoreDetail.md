A more formal flow chart on the logic of creating an `OAuthClient`

#### Creating `OAuthClient` Flow Chart
![Create OAuthClient Flow Chart](./CreateOAuthClientFlowChart.svg "Create OAuthClient Flow Chart")

#### Expanding on 2nd Step - Getting AppCredentials
![Getting AppCredentials](./SecondStepGettingAppCredentials.svg "Getting AppCredentials")