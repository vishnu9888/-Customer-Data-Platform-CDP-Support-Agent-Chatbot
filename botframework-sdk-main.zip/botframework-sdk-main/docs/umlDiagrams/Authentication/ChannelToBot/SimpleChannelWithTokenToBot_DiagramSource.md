```mermaid
    graph LR
        Channel -- Token --> Bot(Bot)
```