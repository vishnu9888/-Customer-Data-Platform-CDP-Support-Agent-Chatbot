```mermaid
    graph LR
        Channel -- "#quot;Why hello, Bot!#quot;" --> Bot(Bot)
```