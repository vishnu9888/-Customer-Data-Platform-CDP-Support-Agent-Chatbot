```mermaid
graph LR

User -- "#quot;Please check my email#quot;" --> Bot(Bot)

```
