```mermaid
    graph  LR
    User --> Bot(Bot) -- Token --> ProtectedResource{{Protected Resource}}
```