```mermaid
    graph LR
    User -- Authenticates Identity at --> AuthServer[/Authorization Server\]
```